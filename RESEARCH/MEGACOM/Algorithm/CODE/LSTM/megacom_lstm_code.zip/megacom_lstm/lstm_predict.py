"""5초 주기 최신 ai_oiltemp.id 조회 → 4개 LSTM 추론 → ai_lstm_r 저장.
설명값은 SHAP이 아닌 Integrated Gradients 근사치(℃)입니다.
"""
import argparse, json, time, logging
from datetime import timedelta
import numpy as np
import pandas as pd
import joblib
import mysql.connector
from config import (DB_CONFIG,COMCODE,DEVICE_ID,MODEL_DIR,HORIZONS,FEATURES,INPUT_MINUTES,MODEL_VERSION)
from lstm_features import minute_features

LOG=logging.getLogger('lstm_predict')

def get_latest(conn,comcode,device_id):
    sql='SELECT id,comcode,device_id,input_time FROM ai_oiltemp WHERE comcode=%s AND device_id=%s ORDER BY id DESC LIMIT 1'
    cur=conn.cursor(dictionary=True)
    try:
        cur.execute(sql,(comcode,device_id));return cur.fetchone()
    finally:cur.close()

def get_history(conn,latest):
    # 최소 35분 이력 + 데이터 수집 지연 여유. 기준 시각 이후 데이터는 절대 사용하지 않음.
    end=latest['input_time'];start=end-timedelta(minutes=38)
    cols=['input_time','io003','io028','io010','io044','io045','io046','io048','io007','io008','io009','io004','io005']
    sql=f'''SELECT {','.join(cols)} FROM ai_oiltemp
       WHERE comcode=%s AND device_id=%s AND input_time>%s AND input_time<=%s
       ORDER BY input_time ASC, id ASC'''
    cur=conn.cursor(dictionary=True)
    try:
        cur.execute(sql,(latest['comcode'],latest['device_id'],start,end))
        return pd.DataFrame(cur.fetchall())
    finally:cur.close()

def integrated_gradients(model,x,sy,steps=16):
    """기준점: 표준화 공간의 0(훈련 평균). 30시점 기여도를 변수별 합산, ℃.
    SHAP이 아님. IG 수치 적분 오차가 있을 수 있음.
    """
    import tensorflow as tf
    z=tf.convert_to_tensor(x,dtype=tf.float32)
    baseline=tf.zeros_like(z)
    total=tf.zeros_like(z)
    for a in np.linspace(0,1,steps+1)[1:]:
        v=baseline+float(a)*(z-baseline)
        with tf.GradientTape() as tape:
            tape.watch(v)
            y=model(v,training=False)
        total+=tape.gradient(y,v)
    attrs=(z-baseline)*total/steps
    by_feature=tf.reduce_sum(attrs,axis=1).numpy()[0]*float(sy.scale_[0])
    return {f:round(float(v),4) for f,v in zip(FEATURES,by_feature)}

def write_results(conn,latest,outputs,importances,contributions,version):
    # 테이블에 (oiltemp_id,prediction_horizon_min,model_version) UNIQUE KEY 권장
    sql='''INSERT INTO ai_lstm_r
      (oiltemp_id,comcode,device_id,input_time,current_datetime,
       prediction_horizon_min,prediction_target_time,lstm_prediction,
       lstm_anomaly_score,feature_importance,feature_contributions,model_version,created_at)
       VALUES (%s,%s,%s,%s,NOW(3),%s,%s,%s,NULL,%s,%s,%s,NOW(3))
       ON DUPLICATE KEY UPDATE
         lstm_prediction=VALUES(lstm_prediction),
         feature_importance=VALUES(feature_importance),
         feature_contributions=COALESCE(VALUES(feature_contributions),feature_contributions),
         current_datetime=NOW(3)'''
    cur=conn.cursor()
    try:
        for h,pred in outputs.items():
            imp=json.dumps(importances[h],ensure_ascii=False)
            contrib=json.dumps({'method':'integrated_gradients','unit':'C','values':contributions[h]},ensure_ascii=False) if contributions.get(h) is not None else None
            cur.execute(sql,(int(latest['id']),latest['comcode'],latest['device_id'],latest['input_time'],h,latest['input_time']+timedelta(minutes=h),round(float(pred),2),imp,contrib,version))
        conn.commit()
    except Exception:
        conn.rollback();raise
    finally:cur.close()

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--once',action='store_true',help='1회 예측 후 종료')
    p.add_argument('--interval',type=float,default=5)
    p.add_argument('--explain-every',type=int,default=12,help='몇 번의 새 ID마다 기여도 계산할지 (0=미계산)')
    p.add_argument('--comcode',default=COMCODE)
    p.add_argument('--device-id',default=DEVICE_ID)
    args=p.parse_args()
    if not args.comcode or not args.device_id: p.error('--comcode 및 --device-id 지정 필요')
    if args.explain_every<0:p.error('--explain-every >= 0')
    from tensorflow.keras.models import load_model
    meta=json.loads((MODEL_DIR/'metadata.json').read_text(encoding='utf-8'))
    if tuple(meta['features'])!=FEATURES or meta['input_minutes']!=INPUT_MINUTES or tuple(meta['horizons'])!=HORIZONS:
        raise ValueError('학습 모델과 추론 설정이 다릅니다.')
    sx=joblib.load(MODEL_DIR/'scaler_X.pkl');sy=joblib.load(MODEL_DIR/'scaler_y.pkl')
    models={h:load_model(MODEL_DIR/f'lstm_{h}min.keras',compile=False) for h in HORIZONS}
    imps={h:json.loads((MODEL_DIR/f'importance_{h}min.json').read_text(encoding='utf-8')) for h in HORIZONS}
    last_success=None;count=0
    while True:
        conn=None
        try:
            conn=mysql.connector.connect(**DB_CONFIG)
            latest=get_latest(conn,args.comcode,args.device_id)
            if latest is None: LOG.warning('원본 데이터 없음')
            elif latest['id']!=last_success:
                hist=get_history(conn,latest)
                if hist.empty: raise ValueError('과거 데이터 없음')
                m=minute_features(hist,anchor=latest['input_time'],realtime=True)
                tail=m.iloc[-INPUT_MINUTES:]
                if tail.isna().any().any():
                    bad=tail.index[tail.isna().any(axis=1)]
                    raise ValueError(f'과거 30분 입력 결측/수집 간격 불충분: {len(bad)}분')
                x=sx.transform(tail[list(FEATURES)]).astype('float32').reshape(1,INPUT_MINUTES,len(FEATURES))
                outputs={h:float(sy.inverse_transform(models[h].predict(x,verbose=0))[0,0]) for h in HORIZONS}
                explain=args.explain_every>0 and (count%args.explain_every==0)
                contributions={h:integrated_gradients(models[h],x,sy) if explain else None for h in HORIZONS}
                write_results(conn,latest,outputs,imps,contributions,meta['version'])
                last_success=latest['id'];count+=1
                LOG.info('저장 완료 oiltemp_id=%s predictions=%s IG=%s',last_success,outputs,explain)
            if args.once:break
        except (Exception) as e:
            LOG.exception('예측/DB 처리 실패: %s',e)
            if args.once:raise
        finally:
            if conn is not None and conn.is_connected():conn.close()
        time.sleep(args.interval)
if __name__=='__main__':
    logging.basicConfig(level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s')
    main()
